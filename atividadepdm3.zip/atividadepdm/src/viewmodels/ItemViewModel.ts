import { useState } from 'react';
import { Item } from '../models/Item';
import { ItemService } from '../services/ItemService';

export const useItemViewModel = () => {
  const [items, setItems] = useState<Item[]>([]);
  const [inputValue, setInputValue] = useState('');

  const addItem = () => {
    const name = inputValue.trim();

    if (ItemService.isDuplicate(name, items)) {
      alert('Este item já existe na lista.');
      return;
    }

    const newItem: Item = {
      id: Date.now().toString(),
      name: name,
    };

    setItems([...items, newItem]);
    setInputValue(''); // Limpa o campo
  };

  return {
    items,
    inputValue,
    setInputValue,
    addItem,
  };
};