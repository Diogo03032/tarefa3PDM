import { Item } from '../models/Item';

export const ItemService = {

  isDuplicate: (name: string, items: Item[]): boolean => {
    return items.some(item => item.name.toLowerCase() === name.trim().toLowerCase());
  }
};