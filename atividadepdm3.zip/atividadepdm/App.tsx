import React from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList, SafeAreaView } from 'react-native';
import { useItemViewModel } from './src/viewmodels/ItemViewModel';

export default function App() {
  const { items, inputValue, setInputValue, addItem } = useItemViewModel();

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Cadastro Simples</Text>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Digite um nome..."
          value={inputValue}
          onChangeText={setInputValue}
        />
        <TouchableOpacity style={styles.button} onPress={addItem}>
          <Text style={styles.buttonText}>+</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemCard}>
            <Text style={styles.itemText}>{item.name}</Text>
            <Text style={styles.itemId}>ID: {item.id.slice(-4)}</Text>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff', marginTop: 30 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  inputContainer: { flexDirection: 'row', marginBottom: 20 },
  input: { flex: 1, borderBottomWidth: 1, borderColor: '#000', padding: 5},
  button: { backgroundColor: '#000', width: 50, justifyContent: 'center', alignItems: 'center', borderRadius: 5 },
  buttonText: { color: '#fff', fontSize: 20 },
  itemCard: { padding: 15, borderBottomWidth: 2, borderColor: '#eee', flexDirection: 'row', justifyContent: 'space-between' },
  itemText: { fontSize: 16, fontWeight: '500' },
  itemId: { color: '#888', fontSize: 12 }
});